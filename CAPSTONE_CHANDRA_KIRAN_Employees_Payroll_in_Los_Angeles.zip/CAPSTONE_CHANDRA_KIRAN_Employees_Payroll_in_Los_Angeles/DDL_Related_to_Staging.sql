-- Staging table used to temporarily store raw data from various sources before it is processed and loaded into the data warehouse's fact and dimension tables.
CREATE TABLE STG_EmployeePayroll(
	RecordNumber VARCHAR(255) NULL, -- Unique identifier for each employee record.
	PayYear INT NULL, --The year of the payroll record.
	DepartmentNumber INT NULL, -- Identifies the department the employee belongs to.
	DepartmentTitle VARCHAR(255) NULL, -- The name of the department.
	JobClassPGrade VARCHAR(255) NULL, -- The job classification and pay grade.
	JobTitle VARCHAR(255) NULL, -- The title of the employee's job.
	EmploymentType VARCHAR(255) NULL, -- The type of employment (e.g., full-time, part-time).
	JobStatus VARCHAR(255) NULL, -- The status of the employee's job.
	MOU VARCHAR(255) NULL, -- Memorandum of Understanding, a legal agreement.
	MOU_Title VARCHAR(255) NULL, -- The title of the MOU.
	RegularPay FLOAT NULL, 
	OvertimePay FLOAT NULL,
	AllOtherPay FLOAT NULL,
	TotalPay FLOAT NULL, -- Summation of RegularPay OvertimePay AllOtherPay 
	CityRetirementContributions FLOAT NULL,
	BenefitPay FLOAT NULL,
	Gender VARCHAR(255) NULL, -- Demographic information about the employee.
	Ethnicity VARCHAR(255) NULL -- Demographic information about the employee.
);
