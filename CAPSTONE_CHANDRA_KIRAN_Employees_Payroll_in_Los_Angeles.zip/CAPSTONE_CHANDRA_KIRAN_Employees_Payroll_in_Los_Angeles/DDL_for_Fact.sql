CREATE TABLE Fact_Payroll (
	Payroll_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	Emp_Key INT REFERENCES DimEmployee(EmpKey), -- Foreign key referencing the employee in the Dim_Employee table.
	Pay_Year INT, --  The year of the payroll.
	Department_Key INT REFERENCES Dim_Department(Department_Key), -- Foreign key
	Job_Class_Pgrade INT REFERENCES Dim_JobClassPgrade(JobClassPgrade_Key), -- Foreign key
	Job_Title_Key INT REFERENCES Dim_JobTitle(JobTitle_Key), -- Foreign key
	Emp_Type_Key INT REFERENCES Dim_EmpType(Emp_Type_Key),  -- Foreign key
	JobStatus_Key INT REFERENCES Dim_JobStatus(Job_Status_Key), -- Foreign key
	Mou_Key INT REFERENCES Dim_Mou(Mou_Key), -- Foreign key
	Regular_Pay DECIMAL(102),
	Overtime_Pay DECIMAL(102),
	All_Other_Pay DECIMAL(102),
	Total_Pay DECIMAL(102),
	City_Retirement_Contributions DECIMAL(102),
	Benefit_Pay DECIMAL(102),
	Create_Date DATETIME, -- Record created Timestamp
	Update_Date DATETIME -- Record updated Timestamp
);