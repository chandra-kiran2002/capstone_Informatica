CREATE TABLE Dim_Ethnicity (
	Ethnicity_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	Ethnicity VARCHAR(255), -- The descriptive name of the category
	Create_Date DATETIME, -- Record created Timestamp
	Update_Date DATETIME -- Record Updated Timestamp
);


CREATE TABLE Dim_Gender (
	Gender_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	Gender VARCHAR(255), -- The descriptive name of the category
	Create_Date DATETIME, -- Record created Timestamp
	Update_Date DATETIME -- Record Updated Timestamp
);

-- This dimension table links employee-specific information (like Record Number, Gender, and Ethnicity) to the corresponding keys in the Ethnicity and Gender dimension tables.
CREATE TABLE Dim_Employee (
	Emp_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	Record_Nbr VARCHAR(255),
	Gender_Key INT REFERENCES Dim_Gender(Gender_Key),
	Ethnicity_Key INT REFERENCES Dim_Ethnicity(Ethnicity_Key),
	Create_Date DATETIME, -- Record created Timestamp
	Update_Date DATETIME -- Record Updated Timestamp
);

CREATE TABLE Dim_Emp_Type(
	Emp_Type_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	Emp_Type varchar(20), -- The descriptive name of the category
	CreateDate DATETIME,-- Record created Timestamp
	UpdateDate DATETIME -- Record Updated Timestamp
);

CREATE TABLE Dim_JobStatus (
	Jobstatus_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	JobStatus VARCHAR(255), -- The descriptive name of the category
	Create_Date DATETIME,-- Record created Timestamp
	update_date DATETIME -- Record Updated Timestamp
);

CREATE TABLE Dim_Job_Class_Pgrade (
	JobClassPgradeKey INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	JobClassPgrade VARCHAR(255), -- The descriptive name of the category
	CreateDate DATETIME,-- Record created Timestamp
	UpdateDate DATETIME -- Record Updated Timestamp
);

CREATE TABLE Dim_Job_Title (
	Job_Title_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	JobT_itle VARCHAR(255), -- The descriptive name of the category
	Create_Date DATETIME,-- Record created Timestamp
	Update_Date DATETIME -- Record Updated Timestamp
);


CREATE TABLE Dim_Department (
	Department_Key INT PRIMARY KEY, -- Unique identifier for each record in the dimension table
	Start_Year INT, -- The Start Year of the Department title
	End_Year INT, -- The end year of the Department title
	Department_No INT,
	Department_Title VARCHAR(255) ,
	Create_Date DATETIME,-- Record created Timestamp
	Update_Date DATETIME -- Record Updated Timestamp
);
