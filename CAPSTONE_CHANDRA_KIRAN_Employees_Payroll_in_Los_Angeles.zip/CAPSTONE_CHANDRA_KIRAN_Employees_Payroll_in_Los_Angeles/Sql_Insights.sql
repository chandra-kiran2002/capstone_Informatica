-- 1. This query calculates gender diversity within departments.

SELECT d.Department_Title, 
	COUNT(DISTINCT CASE WHEN g.Gender = 'Male' THEN e.Record_Nbr ELSE NULL END) AS Distinct_Male_Count, 
	COUNT(DISTINCT CASE WHEN g.Gender = 'Female' THEN e.Record_Nbr ELSE NULL END) AS Distinct_Female_Count,
	COUNT(DISTINCT e.Record_Nbr) AS Total_Distinct_Employees
FROM Dim_Department d
JOIN Fact_Payroll fp ON d.Department_Key = fp.Department_Key
JOIN Dim_Employee e ON fp.Emp_Key = e.Emp_Key
JOIN Dim_Gender g ON e.Gender_Key = g.Gender_Key
GROUP BY d.Department_Title
ORDER BY Total_Distinct_Employees DESC;



-- 2. This query calculates the average total pay for employees, categorized by department and job title, providing insights into how pay is distributed across different roles in the organization.


SELECT dd.Department_Title, jt.Job_Title, AVG(fp.Total_Pay) AS Avg_Total_Payroll
FROM Fact_Payroll fp
JOIN Dim_Department dd ON fp.Department_Key = dd.Department_Key
JOIN Dim_Job_Title jt ON fp.Job_Title_Key = jt.Job_Title_Key
GROUP BY dd.Department_Title, jt.Job_Title
ORDER BY dd.Department_Title, jt.Job_Title


-- 3. query provides a breakdown of the payroll summary for each department in percentages.

SELECT 
    Dim_Department.Department_Title,
    CAST(AVG(Fact_Payroll.Total_Pay) as int) as Avg_TotalPay,
    CAST((SUM(Fact_Payroll.Regular_Pay) / SUM(Fact_Payroll.Total_Pay)) * 100 as int) AS Regular_Pay_Percentage,
    CAST((SUM(Fact_Payroll.Overtime_Pay) / SUM(Fact_Payroll.Total_Pay)) * 100 as int)AS Overtime_Pay_Percentage,
    CAST((SUM(Fact_Payroll.All_Other_Pay) / SUM(Fact_Payroll.Total_Pay)) * 100 as int) AS All_Other_Pay_Percentage
FROM Fact_Payroll
JOIN Dim_Department ON Fact_Payroll.Department_Key = Dim_Department.Department_Key
GROUP BY Dim_Department.Department_Title
ORDER BY CAST(AVG(Fact_Payroll.Total_Pay) as int) DESC


-- 4 .This query tracks the number of active employees in each year, showing how the workforce changes over time.

WITH EmployeeCount AS (
    SELECT Pay_Year, COUNT(DISTINCT IIF(js.jobstatus = 'Active',fp.emp_key,NULL)) AS Total_Active_Employees
    FROM fact_payroll fp
    LEFT JOIN dim_jobstatus js ON fp.jobstatus_key = js.jobstatus_key
    GROUP BY Pay_Year
)
SELECT ec.Pay_Year, ec.Total_Active_Employees,
       COALESCE(LAG(ec.Total_Active_Employees) OVER (ORDER BY ec.Pay_Year), 0) AS Previous_Year_Employees,
       CASE
           WHEN COALESCE(LAG(ec.Total_Active_Employees) OVER (ORDER BY ec.Pay_Year), 0) = 0
           THEN NULL
           ELSE (ec.Total_Active_Employees - COALESCE(LAG(ec.Total_Active_Employees) OVER (ORDER BY ec.Pay_Year), 0)) * 100 /
                COALESCE(LAG(ec.Total_Active_Employees) OVER (ORDER BY ec.Pay_Year), 1)
       END AS Change_Percentage
FROM EmployeeCount ec
ORDER BY ec.Pay_Year;


-- 5. This query calculates the number of active employees in each department and year, and then shows how this number changes from one year to the next.
WITH EmployeeCount AS (
    SELECT dd.Department_Title, fp.Pay_Year,
           COUNT(DISTINCT IIF(dj.JobStatus = 'ACTIVE', fp.Emp_Key, NULL)) AS Active_Employees
    FROM Fact_Payroll fp
    LEFT JOIN Dim_Department dd ON fp.Department_Key = dd.Department_Key AND fp.Pay_Year >= dd.Start_Year AND fp.Pay_Year <= dd.End_Year
    LEFT JOIN Dim_JobStatus dj ON dj.JobStatus_Key = fp.JobStatus_Key
    GROUP BY dd.Department_Title, fp.Pay_Year
)
SELECT ec.Department_Title, ec.Pay_Year, ec.Active_Employees,
       LAG(ec.Active_Employees) OVER (PARTITION BY ec.Department_Title ORDER BY ec.Pay_Year) AS Previous_Year_Count,
       ec.Active_Employees - LAG(ec.Active_Employees) OVER (PARTITION BY ec.Department_Title ORDER BY ec.Pay_Year) AS Change_In_Count,
       CASE 
           WHEN LAG(ec.Active_Employees) OVER (PARTITION BY ec.Department_Title ORDER BY ec.Pay_Year) = 0
           THEN NULL
           ELSE (ec.Active_Employees - LAG(ec.Active_Employees) OVER (PARTITION BY ec.Department_Title ORDER BY ec.Pay_Year))*100 / 
		   NULLIF(LAG(ec.Active_Employees) OVER (PARTITION BY ec.Department_Title ORDER BY ec.Pay_Year), 0)
       END AS Change_Percentage
FROM EmployeeCount ec
ORDER BY ec.Department_Title, ec.Pay_Year;





















